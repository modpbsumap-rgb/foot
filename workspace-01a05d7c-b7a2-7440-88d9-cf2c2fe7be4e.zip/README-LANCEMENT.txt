MANAGER ELITE — LANCEMENT

1. Garde le dossier complet avec index.html et le dossier assets.
2. Sur Windows, double-clique sur LANCER-MANAGER.bat.
3. Une page s'ouvrira sur http://localhost:8000/index.html.

Tu peux aussi double-cliquer sur index.html. Si les logos ne s'affichent pas en mode fichier, utilise LANCER-MANAGER.bat : le navigateur a parfois besoin d'un petit serveur local pour charger les images.
