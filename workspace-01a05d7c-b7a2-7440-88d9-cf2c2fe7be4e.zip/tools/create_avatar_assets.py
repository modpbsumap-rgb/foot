from pathlib import Path
from PIL import Image, ImageDraw
import random

W, H = 512, 1024
ROOT = Path('/home/user/assets/avatar')
random.seed(42)

SKIN = (188, 133, 101, 255)
SKIN_LIGHT = (218, 164, 125, 255)
SKIN_HI = (232, 184, 145, 255)
SKIN_SHADOW = (133, 84, 70, 255)
SKIN_DEEP = (91, 57, 55, 255)
OUTLINE = (20, 27, 35, 255)
INK = (27, 31, 37, 255)


def rgba(rgb, a=255):
    return (rgb[0], rgb[1], rgb[2], a)


def new_layer():
    return Image.new('RGBA', (W, H), (0, 0, 0, 0))


def poly(d, pts, fill, outline=OUTLINE, width=5):
    d.polygon(pts, fill=fill)
    if outline:
        d.line(pts + [pts[0]], fill=outline, width=width, joint='curve')


def rr(d, box, radius, fill, outline=OUTLINE, width=5):
    d.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def px(d, x, y, w, h, fill):
    d.rectangle((x, y, x + w - 1, y + h - 1), fill=fill)


def texture(im, box, colors, count=70, max_size=4):
    d = ImageDraw.Draw(im)
    x1, y1, x2, y2 = box
    for _ in range(count):
        x = random.randint(x1, x2)
        y = random.randint(y1, y2)
        if im.getpixel((max(0, min(W-1, x)), max(0, min(H-1, y))))[3] > 0:
            c = random.choice(colors)
            sz = random.choice([1, 2, 2, 3, max_size])
            px(d, x, y, sz, random.choice([1, 2, 2, 3]), c)


def save(im, sub, name):
    path = ROOT / sub / name
    path.parent.mkdir(parents=True, exist_ok=True)
    im.save(path, 'PNG', optimize=True)


def make_body():
    im = new_layer(); d = ImageDraw.Draw(im)
    # Legs and feet: natural tapered anatomy, not blocks.
    poly(d, [(202, 540), (251, 541), (250, 700), (247, 827), (241, 918), (199, 918), (204, 815)], SKIN, OUTLINE, 6)
    poly(d, [(261, 541), (310, 540), (308, 815), (313, 918), (271, 918), (265, 829)], SKIN, OUTLINE, 6)
    # Calf and knee lighting.
    poly(d, [(207, 694), (245, 694), (242, 820), (235, 879), (209, 879), (214, 807)], SKIN_LIGHT, None)
    poly(d, [(267, 694), (303, 694), (300, 807), (306, 880), (278, 880), (270, 820)], SKIN_LIGHT, None)
    px(d, 202, 748, 8, 50, SKIN_SHADOW); px(d, 301, 748, 8, 48, SKIN_SHADOW)
    # Shoes with small realistic panels and soles.
    rr(d, (190, 895, 252, 962), 16, (47, 54, 64, 255), OUTLINE, 6)
    rr(d, (260, 895, 322, 962), 16, (47, 54, 64, 255), OUTLINE, 6)
    rr(d, (186, 946, 254, 974), 12, (18, 23, 29, 255), OUTLINE, 5)
    rr(d, (258, 946, 326, 974), 12, (18, 23, 29, 255), OUTLINE, 5)
    poly(d, [(201, 906), (232, 905), (244, 922), (205, 931)], (87, 99, 112, 255), None)
    poly(d, [(277, 905), (308, 905), (318, 922), (278, 931)], (87, 99, 112, 255), None)
    px(d, 202, 944, 40, 4, (161, 174, 187, 255)); px(d, 274, 944, 41, 4, (161, 174, 187, 255))
    # Arms behind torso, gently bent by anatomy rather than rectangles.
    poly(d, [(171, 238), (204, 247), (197, 391), (191, 518), (176, 556), (151, 541), (158, 425)], SKIN, OUTLINE, 6)
    poly(d, [(341, 238), (308, 247), (315, 391), (321, 518), (336, 556), (361, 541), (354, 425)], SKIN, OUTLINE, 6)
    poly(d, [(165, 270), (194, 278), (188, 394), (178, 482), (164, 476), (169, 373)], SKIN_LIGHT, None)
    poly(d, [(318, 278), (347, 270), (343, 373), (348, 476), (334, 482), (324, 394)], SKIN_LIGHT, None)
    # Simple visible hands with fingers.
    rr(d, (149, 524, 190, 591), 17, SKIN_LIGHT, OUTLINE, 5)
    rr(d, (322, 524, 363, 591), 17, SKIN_LIGHT, OUTLINE, 5)
    for x in [158, 167, 176]:
        d.line((x, 553, x - 2, 576), fill=SKIN_SHADOW, width=2)
    for x in [336, 345, 354]:
        d.line((x, 553, x + 2, 576), fill=SKIN_SHADOW, width=2)
    # Torso and neck remain in the base so every garment aligns to one body.
    poly(d, [(230, 185), (282, 185), (288, 252), (224, 252)], SKIN, OUTLINE, 6)
    poly(d, [(223, 224), (289, 224), (334, 251), (316, 566), (196, 566), (178, 251)], SKIN, OUTLINE, 6)
    poly(d, [(233, 190), (279, 190), (280, 232), (232, 232)], SKIN_LIGHT, None)
    poly(d, [(184, 258), (211, 247), (204, 520), (194, 550), (181, 526)], SKIN_LIGHT, None)
    poly(d, [(328, 258), (301, 247), (308, 520), (318, 550), (331, 526)], SKIN_LIGHT, None)
    # Head/ears are neutral and intentionally featureless; face layers supply features.
    rr(d, (191, 55, 321, 211), 55, SKIN, OUTLINE, 6)
    rr(d, (183, 117, 205, 163), 10, SKIN, OUTLINE, 4)
    rr(d, (307, 117, 329, 163), 10, SKIN, OUTLINE, 4)
    poly(d, [(200, 87), (217, 69), (293, 69), (312, 93), (305, 137), (295, 105), (218, 105), (208, 137)], SKIN_LIGHT, None)
    poly(d, [(201, 170), (218, 193), (239, 204), (275, 204), (297, 193), (312, 170), (300, 203), (278, 215), (232, 215), (211, 202)], SKIN_SHADOW, None)
    # Pixel clusters for HD pixel-art surface detail.
    texture(im, (195, 65, 319, 205), [SKIN_LIGHT, SKIN_HI, SKIN_SHADOW], 95, 3)
    texture(im, (160, 245, 350, 580), [SKIN_LIGHT, SKIN_SHADOW], 70, 3)
    texture(im, (205, 555, 307, 905), [SKIN_LIGHT, SKIN_SHADOW], 45, 3)
    return im


def face_layer(variant):
    im = new_layer(); d = ImageDraw.Draw(im)
    # Consistent eye line and facial placement across every variation.
    if variant == 1:
        brow = (38, 31, 31, 255); eye = (28, 35, 39, 255); mouth = (116, 61, 60, 255)
        d.line((218, 121, 244, 116), fill=brow, width=6); d.line((268, 116, 294, 121), fill=brow, width=6)
        rr(d, (220, 127, 244, 143), 7, (235, 231, 218, 255), None); rr(d, (268, 127, 292, 143), 7, (235, 231, 218, 255), None)
        px(d, 229, 131, 7, 8, eye); px(d, 277, 131, 7, 8, eye)
        d.line((256, 137, 249, 163, 258, 166), fill=SKIN_SHADOW, width=3)
        d.line((238, 181, 256, 187, 276, 181), fill=mouth, width=4)
    elif variant == 2:
        brow = (44, 34, 29, 255); eye = (47, 37, 33, 255); mouth = (102, 54, 56, 255)
        d.line((217, 118, 244, 124), fill=brow, width=5); d.line((268, 124, 296, 118), fill=brow, width=5)
        d.ellipse((219, 126, 244, 144), fill=(235, 231, 218, 255)); d.ellipse((268, 126, 293, 144), fill=(235, 231, 218, 255))
        px(d, 227, 132, 8, 7, eye); px(d, 276, 132, 8, 7, eye)
        d.line((256, 137, 247, 164, 258, 169), fill=SKIN_SHADOW, width=4)
        d.line((236, 183, 256, 188, 279, 182), fill=mouth, width=4)
        px(d, 209, 157, 8, 5, (209, 129, 116, 255)); px(d, 295, 157, 8, 5, (209, 129, 116, 255))
    elif variant == 3:
        brow = (32, 29, 30, 255); eye = (39, 30, 28, 255); mouth = (132, 67, 64, 255)
        d.line((218, 120, 244, 119), fill=brow, width=7); d.line((268, 119, 294, 120), fill=brow, width=7)
        rr(d, (218, 128, 246, 143), 6, (239, 234, 217, 255), None); rr(d, (266, 128, 294, 143), 6, (239, 234, 217, 255), None)
        px(d, 230, 132, 7, 8, eye); px(d, 275, 132, 7, 8, eye)
        d.line((256, 137, 254, 163, 265, 166), fill=SKIN_SHADOW, width=3)
        d.line((239, 181, 256, 185, 274, 181), fill=mouth, width=3)
    else:
        brow = (37, 29, 26, 255); eye = (30, 35, 38, 255); mouth = (104, 59, 60, 255)
        d.line((216, 117, 244, 113), fill=brow, width=5); d.line((268, 113, 297, 117), fill=brow, width=5)
        d.ellipse((218, 126, 245, 144), fill=(236, 232, 219, 255)); d.ellipse((267, 126, 294, 144), fill=(236, 232, 219, 255))
        px(d, 229, 131, 7, 9, eye); px(d, 276, 131, 7, 9, eye)
        d.line((256, 137, 247, 164, 257, 167), fill=SKIN_SHADOW, width=3)
        d.line((236, 183, 256, 188, 278, 183), fill=mouth, width=5)
    # Small pixel highlights make the face read as HD pixel art, not flat vector art.
    px(d, 216, 110, 5, 3, SKIN_HI); px(d, 292, 110, 5, 3, SKIN_HI)
    px(d, 246, 177, 4, 2, SKIN_LIGHT); px(d, 263, 174, 4, 2, SKIN_LIGHT)
    save(im, 'faces', f'face_0{variant}.png')


def clear_hair_face_opening(im, top=104):
    # Keeps the fringe above the brow line and leaves eyes, nose and mouth visible.
    d = ImageDraw.Draw(im)
    d.polygon([(212, top + 18), (224, top + 8), (241, top + 12), (256, top + 9), (272, top + 12), (289, top + 8), (301, top + 18), (301, 181), (292, 194), (220, 194), (212, 181)], fill=(0, 0, 0, 0))


def hair_layer(style):
    im = new_layer(); d = ImageDraw.Draw(im)
    dark = (30, 30, 36, 255); mid = (54, 49, 51, 255); hi = (94, 83, 79, 255); black = (18, 20, 25, 255)
    if style == 'short':
        d.ellipse((193, 38, 319, 144), fill=dark, outline=OUTLINE, width=6)
        poly(d, [(198, 100), (210, 72), (232, 51), (276, 44), (307, 69), (315, 107), (298, 91), (292, 76), (234, 76), (215, 104)], mid, None)
        poly(d, [(197, 111), (211, 98), (215, 147), (203, 158)], dark, None)
        poly(d, [(315, 111), (301, 98), (297, 147), (309, 158)], dark, None)
        texture(im, (195, 45, 317, 142), [mid, hi, black], 115, 3)
    elif style == 'fade':
        poly(d, [(199, 105), (212, 61), (240, 38), (282, 42), (311, 74), (314, 115), (299, 91), (293, 76), (233, 75), (215, 112)], dark, OUTLINE, 6)
        poly(d, [(218, 74), (239, 49), (280, 49), (301, 76), (287, 83), (236, 82)], mid, None)
        for x in [202, 208, 301, 307]: px(d, x, 106, 5, 31, (77, 70, 70, 255))
        texture(im, (212, 44, 304, 83), [mid, hi, black], 90, 3)
    elif style == 'side_part':
        poly(d, [(193, 116), (202, 72), (232, 42), (285, 44), (321, 81), (317, 127), (298, 98), (277, 72), (241, 74), (215, 111)], dark, OUTLINE, 6)
        poly(d, [(236, 50), (280, 48), (309, 78), (277, 86), (248, 72)], mid, None)
        d.line((248, 52, 238, 84), fill=hi, width=4)
        texture(im, (199, 45, 315, 115), [mid, hi, black], 105, 3)
    elif style == 'curly':
        d.ellipse((186, 34, 326, 154), fill=dark, outline=OUTLINE, width=6)
        for x, y, r in [(204,63,18),(229,45,20),(257,38,20),(286,48,20),(308,70,18),(198,96,18),(315,103,17)]:
            d.ellipse((x-r, y-r, x+r, y+r), fill=mid, outline=black, width=3)
            px(d, x-5, y-7, 7, 4, hi)
        poly(d, [(193, 103), (210, 94), (214, 157), (198, 171)], dark, None)
        poly(d, [(319, 103), (302, 94), (298, 157), (314, 171)], dark, None)
        texture(im, (190, 35, 322, 155), [mid, hi, black], 130, 3)
    elif style == 'afro':
        d.ellipse((169, 26, 343, 190), fill=dark, outline=OUTLINE, width=7)
        d.ellipse((181, 39, 331, 176), fill=mid, outline=black, width=3)
        for x, y in [(193,57),(217,42),(243,34),(271,36),(299,47),(320,66),(182,91),(328,103),(188,130),(321,140)]:
            d.ellipse((x-15, y-15, x+15, y+15), fill=dark, outline=hi, width=2)
        texture(im, (174, 30, 337, 184), [mid, hi, black], 180, 4)
    elif style == 'braids':
        poly(d, [(193, 112), (203, 67), (238, 40), (284, 43), (315, 75), (319, 129), (302, 99), (287, 78), (230, 77), (211, 110)], dark, OUTLINE, 6)
        for x in [211, 232, 254, 276, 298]:
            d.line((x, 55, x-4, 146), fill=mid, width=8)
            for y in range(64, 145, 17):
                d.line((x-5, y, x+7, y+9), fill=hi, width=3)
        for x, lean in [(202,-1),(312,1)]:
            poly(d, [(x, 112), (x+lean*12, 117), (x+lean*17, 235), (x+lean*3, 249)], dark, OUTLINE, 4)
            for y in range(132, 226, 18): d.line((x+lean*4, y, x+lean*13, y+8), fill=hi, width=3)
        texture(im, (198, 44, 314, 145), [mid, hi, black], 100, 3)
    elif style == 'dreadlocks':
        poly(d, [(191, 112), (199, 62), (232, 38), (285, 42), (316, 76), (320, 126), (301, 98), (288, 75), (230, 76), (209, 112)], dark, OUTLINE, 6)
        for x, end in [(203,228),(220,250),(239,232),(282,246),(301,226),(316,205)]:
            d.line((x, 82, x-3, end), fill=mid, width=13)
            d.line((x-3, 89, x+4, end-12), fill=hi, width=3)
            d.line((x+4, 99, x-5, end-28), fill=black, width=3)
        texture(im, (198, 42, 315, 148), [mid, hi, black], 120, 3)
    else:  # long
        poly(d, [(189, 120), (198, 62), (232, 37), (284, 41), (316, 77), (327, 192), (309, 264), (284, 284), (290, 171), (302, 106), (284, 76), (233, 77), (211, 112), (220, 175), (211, 268), (188, 238)], dark, OUTLINE, 7)
        poly(d, [(203, 105), (213, 66), (241, 48), (282, 50), (307, 81), (301, 104), (283, 78), (230, 80)], mid, None)
        for x in [202, 215, 299, 313]:
            d.line((x, 100, x + (x-256)//22, 244), fill=hi, width=4)
        texture(im, (194, 43, 322, 270), [mid, hi, black], 175, 3)
    clear_hair_face_opening(im, 101 if style in ['afro', 'curly'] else 104)
    save(im, 'hair', f'hair_{style}.png')


def clothes_layer(style):
    im = new_layer(); d = ImageDraw.Draw(im)
    if style == 'suit':
        jacket = (39, 47, 59, 255); jacket_hi = (71, 83, 99, 255); shirt = (232, 234, 232, 255); tie = (97, 105, 115, 255); trouser = (32, 39, 49, 255)
        poly(d, [(177, 244), (223, 224), (256, 239), (289, 224), (335, 244), (317, 573), (195, 573)], jacket, OUTLINE, 6)
        poly(d, [(177, 246), (204, 252), (195, 521), (177, 550), (166, 531)], jacket, OUTLINE, 5)
        poly(d, [(335, 246), (308, 252), (317, 521), (335, 550), (346, 531)], jacket, OUTLINE, 5)
        poly(d, [(226, 230), (256, 249), (286, 230), (272, 290), (256, 276), (240, 290)], shirt, OUTLINE, 4)
        poly(d, [(250, 252), (262, 252), (266, 359), (256, 383), (246, 359)], tie, None)
        poly(d, [(228, 242), (245, 276), (233, 321), (213, 249)], jacket_hi, None)
        poly(d, [(284, 242), (267, 276), (279, 321), (299, 249)], jacket_hi, None)
        d.line((256, 279, 256, 558), fill=(110, 121, 134, 255), width=3)
        d.line((207, 530, 305, 530), fill=(87, 98, 113, 255), width=4)
        poly(d, [(200, 552), (252, 552), (248, 918), (199, 918)], trouser, OUTLINE, 5)
        poly(d, [(260, 552), (312, 552), (313, 918), (271, 918)], trouser, OUTLINE, 5)
        texture(im, (180, 240, 338, 915), [jacket_hi, (56, 66, 80, 255), (22, 28, 37, 255)], 155, 3)
    elif style == 'polo':
        polo = (65, 94, 107, 255); polo_hi = (111, 141, 149, 255); pants = (67, 72, 78, 255)
        poly(d, [(180, 245), (224, 225), (256, 241), (288, 225), (332, 245), (316, 570), (196, 570)], polo, OUTLINE, 6)
        poly(d, [(180, 246), (203, 250), (194, 398), (174, 537), (155, 528), (166, 370)], polo, OUTLINE, 5)
        poly(d, [(332, 246), (309, 250), (318, 398), (338, 537), (357, 528), (346, 370)], polo, OUTLINE, 5)
        poly(d, [(225, 229), (256, 249), (287, 229), (273, 282), (256, 294), (239, 282)], polo_hi, OUTLINE, 4)
        d.line((256, 282, 256, 555), fill=(36, 60, 69, 255), width=3)
        poly(d, [(198, 550), (251, 550), (247, 918), (199, 918)], pants, OUTLINE, 5)
        poly(d, [(261, 550), (314, 550), (313, 918), (271, 918)], pants, OUTLINE, 5)
        texture(im, (160, 240, 345, 920), [polo_hi, (48, 74, 85, 255), (92, 102, 110, 255)], 165, 3)
    elif style == 'tracksuit':
        top = (38, 49, 62, 255); stripe = (205, 208, 211, 255); pants = (43, 51, 62, 255)
        poly(d, [(177, 243), (224, 224), (256, 240), (288, 224), (335, 243), (319, 573), (193, 573)], top, OUTLINE, 6)
        poly(d, [(177, 244), (202, 251), (193, 411), (178, 541), (158, 533), (167, 369)], top, OUTLINE, 5)
        poly(d, [(335, 244), (310, 251), (319, 411), (334, 541), (354, 533), (345, 369)], top, OUTLINE, 5)
        d.line((256, 244, 256, 558), fill=(178, 186, 195, 255), width=4)
        poly(d, [(189, 302), (323, 302), (321, 322), (191, 322)], stripe, None)
        poly(d, [(198, 550), (251, 550), (247, 918), (199, 918)], pants, OUTLINE, 5)
        poly(d, [(261, 550), (314, 550), (313, 918), (271, 918)], pants, OUTLINE, 5)
        d.line((206, 578, 239, 900), fill=stripe, width=5); d.line((306, 578, 275, 900), fill=stripe, width=5)
        texture(im, (160, 240, 350, 920), [(60, 72, 87, 255), (25, 34, 45, 255), stripe], 150, 3)
    elif style == 'casual':
        hoodie = (82, 82, 88, 255); hoodie_hi = (137, 140, 145, 255); denim = (68, 83, 100, 255)
        poly(d, [(180, 246), (224, 225), (256, 240), (288, 225), (332, 246), (318, 574), (194, 574)], hoodie, OUTLINE, 6)
        poly(d, [(181, 244), (205, 250), (193, 401), (177, 537), (157, 529), (168, 370)], hoodie, OUTLINE, 5)
        poly(d, [(331, 244), (307, 250), (319, 401), (335, 537), (355, 529), (344, 370)], hoodie, OUTLINE, 5)
        rr(d, (228, 228, 284, 288), 18, (55, 57, 63, 255), OUTLINE, 4)
        d.line((256, 286, 256, 556), fill=hoodie_hi, width=3)
        poly(d, [(197, 550), (251, 550), (247, 918), (199, 918)], denim, OUTLINE, 5)
        poly(d, [(261, 550), (315, 550), (313, 918), (271, 918)], denim, OUTLINE, 5)
        d.line((212, 576, 219, 902), fill=(138, 154, 169, 255), width=3); d.line((300, 576, 293, 902), fill=(138, 154, 169, 255), width=3)
        texture(im, (160, 240, 350, 920), [hoodie_hi, (60, 61, 68, 255), (94, 112, 132, 255)], 165, 3)
    else:  # shirt
        shirt = (185, 188, 184, 255); shirt_hi = (232, 233, 228, 255); chino = (113, 102, 91, 255)
        poly(d, [(181, 245), (224, 225), (256, 241), (288, 225), (331, 245), (317, 570), (195, 570)], shirt, OUTLINE, 6)
        poly(d, [(181, 245), (205, 251), (194, 398), (177, 538), (157, 530), (168, 370)], shirt, OUTLINE, 5)
        poly(d, [(331, 245), (307, 251), (318, 398), (335, 538), (355, 530), (344, 370)], shirt, OUTLINE, 5)
        poly(d, [(224, 229), (256, 250), (288, 229), (273, 289), (256, 278), (239, 289)], shirt_hi, OUTLINE, 4)
        for y in range(303, 527, 45): px(d, 251, y, 10, 6, (92, 96, 97, 255))
        d.line((256, 283, 256, 550), fill=(129, 132, 130, 255), width=2)
        poly(d, [(198, 550), (251, 550), (247, 918), (199, 918)], chino, OUTLINE, 5)
        poly(d, [(261, 550), (314, 550), (313, 918), (271, 918)], chino, OUTLINE, 5)
        texture(im, (160, 240, 350, 920), [shirt_hi, (156, 160, 156, 255), (130, 118, 105, 255)], 165, 3)
    save(im, 'clothes', f'clothes_{style}.png')


def beard_layer(style):
    im = new_layer(); d = ImageDraw.Draw(im)
    stubble = (93, 64, 59, 210); beard = (66, 47, 46, 245); hi = (129, 87, 75, 230)
    if style == 'none':
        pass
    elif style == 'short':
        # Fine clusters follow cheeks, jaw and chin without covering the mouth.
        for x, y in [(214,164),(220,174),(226,180),(232,190),(240,195),(249,200),(262,200),(273,194),(282,188),(290,178),(297,167),(244,192),(268,191)]:
            px(d, x, y, 5, 4, stubble)
        d.line((218, 176, 233, 197, 256, 205, 280, 197, 296, 176), fill=stubble, width=3)
        texture(im, (211, 163, 301, 207), [stubble, hi], 42, 2)
    elif style == 'full':
        poly(d, [(211, 158), (227, 168), (235, 185), (256, 195), (278, 185), (287, 168), (302, 158), (295, 195), (278, 211), (234, 211), (217, 195)], beard, None)
        poly(d, [(238, 181), (256, 188), (275, 181), (270, 207), (244, 207)], hi, None)
        texture(im, (211, 160, 301, 211), [beard, hi, (45, 35, 36, 245)], 100, 3)
    elif style == 'mustache':
        poly(d, [(232, 169), (246, 166), (256, 173), (266, 166), (280, 169), (269, 183), (256, 178), (243, 183)], beard, None)
        texture(im, (232, 166, 280, 184), [beard, hi], 34, 2)
    else:  # goatee
        poly(d, [(233, 169), (247, 166), (256, 173), (266, 166), (280, 169), (269, 181), (256, 178), (243, 181)], beard, None)
        poly(d, [(244, 183), (268, 183), (274, 207), (262, 215), (250, 215), (238, 207)], beard, None)
        texture(im, (238, 166, 275, 216), [beard, hi], 48, 2)
    filename = {'none':'beard_none.png', 'short':'beard_short.png', 'full':'beard_full.png', 'mustache':'mustache.png', 'goatee':'goatee.png'}[style]
    save(im, 'beard', filename)


def accessories_layer(style):
    im = new_layer(); d = ImageDraw.Draw(im)
    metal = (33, 39, 47, 255); light = (188, 199, 208, 255); lens = (100, 118, 132, 105)
    if style == 'glasses':
        rr(d, (211, 119, 250, 148), 8, lens, light, 4); rr(d, (262, 119, 301, 148), 8, lens, light, 4)
        d.line((250, 132, 262, 132), fill=light, width=4); d.line((207, 126, 196, 121), fill=light, width=4); d.line((305, 126, 316, 121), fill=light, width=4)
    elif style == 'glasses_round':
        d.ellipse((210, 116, 250, 155), fill=lens, outline=light, width=4); d.ellipse((262, 116, 302, 155), fill=lens, outline=light, width=4)
        d.line((250, 135, 262, 135), fill=light, width=4); d.line((207, 126, 196, 121), fill=light, width=4); d.line((305, 126, 316, 121), fill=light, width=4)
    else:
        poly(d, [(188, 82), (204, 48), (238, 30), (287, 33), (322, 59), (329, 82), (307, 75), (286, 63), (232, 64), (204, 82)], metal, OUTLINE, 6)
        poly(d, [(186, 82), (233, 67), (288, 67), (330, 82), (325, 94), (283, 82), (233, 82), (191, 95)], light, None)
        d.line((220, 54, 284, 49), fill=(225, 229, 232, 255), width=3)
        texture(im, (190, 34, 326, 91), [light, (93, 104, 115, 255), metal], 50, 3)
    save(im, 'accessories', f'{style}.png')


def main():
    for sub in ['base', 'faces', 'hair', 'clothes', 'beard', 'accessories']:
        (ROOT / sub).mkdir(parents=True, exist_ok=True)
    save(make_body(), 'base', 'body_base.png')
    for i in range(1, 5): face_layer(i)
    for style in ['short', 'fade', 'side_part', 'curly', 'afro', 'braids', 'dreadlocks', 'long']:
        hair_layer(style)
    for style in ['suit', 'polo', 'tracksuit', 'casual', 'shirt']:
        clothes_layer(style)
    for style in ['none', 'short', 'full', 'mustache', 'goatee']:
        beard_layer(style)
    for style in ['glasses', 'glasses_round', 'cap']:
        accessories_layer(style)
    files = list(ROOT.rglob('*.png'))
    print(f'created {len(files)} PNG layers at {ROOT}')
    for p in sorted(files):
        with Image.open(p) as im:
            print(p.relative_to(ROOT), im.size, im.mode)

if __name__ == '__main__':
    main()
