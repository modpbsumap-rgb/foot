@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  start "Manager Elite" http://localhost:8000/index.html
  py -m http.server 8000
  goto :eof
)
where python >nul 2>&1
if %errorlevel%==0 (
  start "Manager Elite" http://localhost:8000/index.html
  python -m http.server 8000
  goto :eof
)
echo Python n'est pas installe.
echo Ouvre index.html directement ou installe Python depuis python.org.
pause